# Rogue positional requirements — bounded binary audit (NO PATCH)

Scope: `parallel`, HEAD at inspection `d00cda982825f147903de4367b2b762ad2c49387`, WoW 1.12.1 build 5875 PE32/i386.

## Exact input

`WoW_5875_BASE_MELEE_300YD_PP_BYPASS_STEALTH5_HARD.exe`; 4,907,008 bytes; SHA256 `9a735271283a49d16ca670d6a6fc8bb12937deca07221087c608b27c2ffd42a2`. The uploaded file matches `CURRENT.json`, `runtime/current.json`, and the EXE entry in the candidate package for `d00cda982825`. The audit script rejects any other EXE.

## Exact-byte evidence (.text: file offset = VA - 0x400000)

| Purpose | File offset | VA | Original bytes | Function role |
|---|---:|---:|---|---|
| `SPELL_FAILED_NOT_BEHIND` | `0x2E2528` | `0x006E2528` | `B8 6C 05 87 00 C3` | `mov eax, 0x0087056C; ret`: returns pointer to error *name* |
| `SPELL_FAILED_NOT_INFRONT` | `0x2E253A` | `0x006E253A` | `B8 1C 05 87 00 C3` | `mov eax, 0x0087051C; ret`: returns pointer to error *name* |
| `DBFilesClient\\Spell.dbc` | `0x183720` | `0x00583720` | `B8 30 9E 85 00 C3` | `mov eax, 0x00859E30; ret`: returns pointer to DBC *path* |

Each pointer has one direct in-text immediate address reference (at the function's `mov` immediate); this **does not** rule out indirect lookups, other data, or actual local checks elsewhere. In particular these three reference functions are **not** positional cast predicates. Altering their text, return address, or failure names would not be a verified positional patch.

## Unresolved questions

- No exact-build target position predicate has been traced from client cast initiation through the outgoing cast packet; it has not been shown whether client prevalidation exists for Rogue position, or for which ranks.
- The actual `Spell.dbc` client data was not supplied or recovered in this audit; spell-rank attribute comparison against the exact file is therefore not proven. No rank-specific binary edits are justified by raw integer matches in machine code.
- An on-screen `SPELL_FAILED_NOT_BEHIND` is **not** sufficient to classify the failure as local or server-originated. The server may independently check caster/target geometry. It is not proven that the user's actual server uses the same spell code as the public Vanilla implementations.
- Gouge has a target-facing condition different from the caster-behind-target condition for Backstab/Ambush; it must be audited separately.

External research, **not** transplanted to the binary: CMaNGOS Vanilla spell result definitions and spell validation source illustrate server-side failures (`https://github.com/cmangos/mangos-classic/blob/master/src/game/Spells/SpellDefines.h`, `https://github.com/cmangos/mangos-classic/blob/master/src/game/Spells/Spell.cpp`). Spell.dbc documentation from other builds cannot establish 5875 field offsets (`https://trinitycore.info/files/DBC/335/spell`). Actual EXE addresses above were obtained only from the exact uploaded client.

## Gate and next discriminating observation

Observe an exact spell attempt with an outgoing `CMSG_CAST_SPELL` and incoming corresponding `SMSG_CAST_FAILED`, and independently establish whether a rejected attempt generated an outgoing cast request. Correlate with the exact spell ID, rank, timestamps, and target/caster orientations without confusing an action-bar highlight with a local cast failure. Attribute any local return to a verified exact-build call chain before patching. Do **not** disable energy, stealth, cooldown, range or weapon requirements. Do not replace this missing proof with a NOP of the error-name string getter.

**Disposition:** no byte of the EXE, runtime DLLs, `CURRENT.json`, `runtime/current.json`, or manifests was changed. No patched EXE or tested patched package exists. The unmodified GitHub candidate package is not evidence of a Rogue positional fix.

Run `python verify_reference_sites.py path/to/exact-WoW.exe` to reproduce the bounded exact-byte findings (read-only). This script is intentionally **not** a positional-patch reproducer.
