#!/usr/bin/env python3
"""Read-only, exact-byte audit. No game EXE modifications or network requests."""
import hashlib
import pathlib
import struct
import sys

EXPECTED_SHA256 = '9a735271283a49d16ca670d6a6fc8bb12937deca07221087c608b27c2ffd42a2'
EXPECTED_SIZE = 4907008
SITES = (
    ('not_behind_name', 0x2e2528, 0x87056c, b'SPELL_FAILED_NOT_BEHIND'),
    ('not_infront_name', 0x2e253a, 0x87051c, b'SPELL_FAILED_NOT_INFRONT'),
    ('spell_dbc_path', 0x183720, 0x859e30, b'DBFilesClient\\Spell.dbc'),
)

def main():
    if len(sys.argv) != 2:
        print('usage: python verify_reference_sites.py <exact-active-WoW.exe>')
        return 2
    data = pathlib.Path(sys.argv[1]).read_bytes()
    size, sha = len(data), hashlib.sha256(data).hexdigest()
    print('file_size=', size, 'sha256=', sha)
    assert size == EXPECTED_SIZE and sha == EXPECTED_SHA256, 'Active EXE identity mismatch; analysis NOT applicable'
    assert data[:2] == b'MZ', 'Missing DOS MZ signature'
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    assert data[pe:pe+4] == b'PE\0\0', 'Missing PE signature'
    machine = struct.unpack_from('<H', data, pe+4)[0]
    magic = struct.unpack_from('<H', data, pe+24)[0]
    assert machine == 0x14c and magic == 0x10b, 'Expected PE32 i386'
    print('pe_machine=0x%04x optional_magic=0x%04x' % (machine, magic))
    for name, off, target, string in SITES:
        target_off = data.find(string)
        assert target_off == target - 0x400000, name + ' string address mismatch'
        actual = data[off:off+6]
        expected = b'\xb8' + struct.pack('<I', target) + b'\xc3'
        assert actual == expected, name + ' instruction mismatch'
        needle = struct.pack('<I', target)
        xrefs = []
        pos = 0x1000
        while True:
            pos = data.find(needle, pos, 0x3fddac+0x1000)
            if pos < 0:
                break
            xrefs.append(pos)
            pos += 1
        assert xrefs == [off+1], name + ' unexpected direct text xrefs (review needed)'
        print('%s file_offset=0x%x VA=0x%x bytes=%s direct_string_address_text_xrefs=%s' %
              (name, off, off + 0x400000, actual.hex(' '), [hex(x) for x in xrefs]))
    print('PASS: read-only identity and name/path reference-site audit; no positional cast predicate proven')
    return 0

if __name__ == '__main__':
    sys.exit(main())
